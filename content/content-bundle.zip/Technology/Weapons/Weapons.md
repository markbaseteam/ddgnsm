****
[[Weapon Template]]
****
[[ElectroKris-X1]]
[[NovaFire-EX1]]
[[Plasmaflare-09]]
[[EAS Luminar X7 Energy Rifle]]
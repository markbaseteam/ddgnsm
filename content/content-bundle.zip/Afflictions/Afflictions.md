[[Affliction Template]]
****
Non-Exclusive
[[Chronosis]]
[[Cellular Cytolysis]]

Exclusive to [[Species - Serpentus Chrysalis]] and hybrids.
[[Unlassia]]
[[Chitin Degradation Disorder (CDD)]]

Exclusive to [[Species - Stella Cursores]] and hybrids.
[[Strider Pulmonitis]]
[[Strider Degenerative Syndrome (SDS)]]
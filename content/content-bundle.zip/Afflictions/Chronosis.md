****
**Name:** Chronosis

**Classification:** Chronic Temporal Affliction

**Origins:** Chronosis was discovered in 2.70 by human scientist Astum Clark during his studies on warp drives. It is believed to originate from unprotected exposure to active warp drives and similar technology.

**Transmission:** Non-Communicable

**Symptoms:**
- Time Dilation: Individuals afflicted with Chronosis experience episodes where they perceive time dilation to different extents. These episodes can range from being stuck in a moment for hours on the short end to years on the high end before time resumes, and they return to their original location.
- Isolation: During time dilation, the frozen moment is only experienced by the afflicted individual, and others around them do not notice this temporal disturbance.
- Sanity Damage: Victims usually exhibit severe damage to their sanity. In more severe cases, it can lead to psychosis.
- Physical Symptoms: Some individuals may experience physical symptoms during time dilation, such as nausea, vomiting, and headaches.

**Incubation Period:** Chronosis does not have a specific incubation period. It occurs during episodes triggered by exposure to warp drives and similar technology.

**Effects on Society:** Chronosis has significant societal consequences, particularly within communities that work with warp drives. It raises ethical questions about the use of such technology and the well-being of those exposed to it.

**Preventive Measures:** To reduce the risk of Chronosis, individuals are advised to wear high-grade protective equipment when working with active warp drives. Proper shielding is essential to minimize exposure to the harmful effects of temporal distortion.

**Diagnosis:** Chronosis is diagnosed based on the observation of its symptoms during time dilation episodes.

**Treatment:** Currently, there are no known cures or specific treatments for Chronosis. The primary approach is to provide mental health support and therapy to help afflicted individuals cope with the disorder's psychological impact.

**Mutation Variants:** Evolved disease variants are possible.

**Vaccines:** Chronosis is not a disease, so vaccines are not applicable.

**Antidotes:** No antidote exists for Chronosis, as it is a chronic temporal affliction.

**Research Efforts:** Ongoing research may focus on understanding the genetic and neurobiological mechanisms behind Chronosis and exploring potential treatments or coping strategies for affected individuals.

**Pandemic Potential:** Risk of widespread outbreak due to improper use of warp drives and a lack of proper protection when using such technology.

**Notable Outbreaks:** Chronosis does not involve notable outbreaks but rather individual cases triggered by exposure to warp drives.

**Countermeasures:** Countermeasures are directed at the safe use of warp drives, including proper shielding, equipment, and safety protocols.

**Public Awareness:** Public awareness efforts may focus on educating those who work with warp drives about the risks of Chronosis and the importance of protective measures.

**Quarantine Protocols:** Quarantine protocols are not applicable to Chronosis, as it is not a contagious disease.

**Effects on Characters:** Characters affected by Chronosis may face personal and psychological challenges due to their experiences with time dilation. It can shape their choices, relationships, and overall character development.

**Narrative Role:** Chronosis plays a pivotal role in the plot and world-building, introducing a unique and dramatic element where individuals are plagued by time dilation, experiencing moments of their lives at drastically different rates. The disease's origins in warp drive technology highlight the risks and dangers of advanced scientific endeavors. It also serves as a plot device, affecting characters and their interactions, as well as raising questions about the ethics and safety of using warp drives. The exploration of how individuals cope with time dilation and its consequences adds depth to the narrative.
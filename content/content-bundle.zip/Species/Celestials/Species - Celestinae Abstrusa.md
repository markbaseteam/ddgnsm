**The Celestials of the Ephemera**


Origins:
The Celestials of the Ephemera have their origins shrouded in perplexity with no exact origin known. Some myths that have circulated suggest a creation based in the chaotic energies of the cosmos itself, forming them into timeless observers of the universe and the many events within it. Other rumors suggest that the Celestials of the Ephemera could actually be sentient manifestations of temporal anomalies, existing in a state of present, past, future, or possibly even outside the concept of time that we understand.

Note: Sometimes the Celestials of the Ephemera will be referred to as the CoEs for the sake of shortening their long title/name.

Physical Appearance:
The Celestials of the Ephemera cannot be fully described with common language and forms of expression, transcending conventional comprehension. From the few rare encounters species have had with these enigmatic beings, mixed reports of their appearance have shown up. Some describe them as ethereal beings that shimmer with a radiance collectively described as otherworldly. Others claim to have glimpsed part of their colossal, iridescent wings that supposedly stretch across space itself. Few others have even mentioned them having forms that were ever-shifting and blended into the fabric of the cosmos itself.

Behaviors/Culture:
The behaviors of the CoEs are just as inscrutable as their origins. From all the data species have on the CoEs we know that they drift through cosmic currents, cosmic currents being the natural paths formed by analyzing the directions solar systems point to when all planets allign. The CoEs seem to appear and disappear without warning, following no pattern from what scholars have been able to tell. Some people claim that the CoEs act as cosmic spectators while others see their appearances as a sort of cosmic intervention that's done to keep balance throughout the cosmos.

The Celestials of the Ephemera's culture is much like the existance of the beings themselves, an enigma due to their reclusive nature. Through tales and rumors, stories of massive celestial libraries exist where they document the past, present, and future of the universe, but these tales have no strong foundation for their existance.

_Interactions with Other Species_: Interactions with the Celestials of the Ephemera are rare and perplexing. For countless eons, they have maintained an isolationist stance, observing events from a celestial distance that leaves sentient species both fascinated and confounded. On rare occasions, individuals claim to have received cryptic visions or profound insights attributed to the Celestials, but the veracity of such encounters remains disputed.

The Celestials' true motives and intentions remain a puzzle to all who seek to understand them. Some speculate that they are benevolent cosmic stewards, guardians of cosmic balance. Others fear their vast knowledge and seemingly dispassionate observations, interpreting them as indifferent cosmic entities beyond the comprehension of mortal minds.

Their isolationist nature and enigmatic presence have left sentient species yearning for answers. Many have dedicated entire eras to unraveling the mysteries of the Celestials, but the veil of uncertainty persists, leaving the Celestials of the Ephemera as profound, unknown celestial wonders, forever entwined with the fabric of the universe's enigmas.
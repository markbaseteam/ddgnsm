The Planetbearers are a race of higher lifeforms capable of the mass terraforming of planets.

Forma Planetarum, known commonly as Planetbearers are a race of lifeforms that through the forming of a deep intimate relationships with other species, terraform planets and create genetically similar replicas of their partners. Found commonly on dead/dying planets and/or barren astroids, Planetbears as a species are very spread out and perfer to be away from each other. This is mostly because of their interests in inter-species relationships. Planetbearers will wander and wait on barren or dead/dying planets until contacted by another species. It's then that a relationship will try to be formed. Some Planetbearers, either based on past relationships or just their personality, can initally come off as cold or unwelcoming, where more effort may need to be put in to form a relationship. Newer Planetbearers are more likely to jump into a relationship due their lack of knowledge on other species and also social normalities.

In terms of physical traits, these vary based on multiple variables that are impact a Planetbearer during it's life. It's hard to interpret features though since different factors may have the same impact. For example, a Planetbearer may have short hair because: The Planetbearer may simply just like its hair short. The Planetbearer might be short tempered, which shows through its hair. The love the Planetbearer experienced was short, shown through hair. Etc. This remains the same for other features that Planetbearers may present. This is not a permenent feature either, as Planetbearts have a limited shapeshifting ability to replicate looks that their partner may be more comfortable or attracted to, only after the relationship has begun though.


Origins & Evolution
[Origins/Evolution]


Physical Description
[Physical Desc]


Medical Notes
[Medical Notes]


Beliefs and Culture
[Beliefs/Culture]


Diplomacy + Interactions with Other Species (WIP)
[Diplomacy/Interactions]

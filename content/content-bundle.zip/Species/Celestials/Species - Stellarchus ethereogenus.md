	Origins

Disclaimer: Most of what we know of the Tartanus comes from a Mutaforma Symbiogenus by the name of Rubix, and due to the way that this information was recieved according to Rubix, there is no current way to fully confirm the validity of the information expressed below. Any information that does not come from Rubix is from the very few documented times that the Tartanus have stepped off their planet to defend themselves or nearby planets.

The Tartanus, commonly referred to as the Titans were very different than what our present day descriptions are of them today. The Titans, as they will be referred to as in this file, were once a race of ancient beings that seemed to date back as far as the Forma Planetarum (Planetbearers) do, that is to say that, we do not know when their existance began. Originally when they still existed in a more physical state, they found their home on a barren clump of spacerock slowly drifting through space. Eventually they found themselves caught in the orbit of what is now Meridian Prime, one of the largest gas giants that exist. At the time though it was a still a forming gas giant that began its creation far before even the first records of space travel.

The Titans, having watched the creation of the planet, decided to travel to the forming gas giant. The Titans then underwent an extremely fast adaption to the gas giant's environment, the physical forms condensing into a core that held extreme levels of matter manipulation. This core then merged into the gases of the planet, coverting it into energy through and forming it into massive humanoid forms. These hulking bodies of energy did not do much in terms of technological advancement from this point on, rather focusing on a spiritual and mental enlightment with the help of the nigh-infinite time they had on their side now.


Physical Description

Tartanus all follow a very simple physical description. A giant gasous body that is humanoid in nature with a large core located usually within their chest. Cores are opaque and usually are a very dark color. Tartanus do not have any facial features or many details in general when it comes to their appearances. There isn't much else documented on their physical description due to lack of contact. Some Titans can be hundreds to thousands of feet tall while the shortest spotted Titan stands at about one hundred and fifty-two feet tall.

Titans also seem capable of manipulating weather patterns on their planet along with the few orbiting moons. There exists multiple accounts of naturally impossible auroras and other non-disruptive weather conditions after the Titans finish their yearly ritual.  

Medical Notes

There is only a singular story that mentions anything with their health that involves some sort of high intensity energy beam striking a Titan and damaging their core. Another Titan took them by the hand and embraced them. The two becoming one for a time while the damaged core mended itself. Once mended the two seperate, but their forms were different, like that had developed in some way. The two never seemed to stray far away from each other after that.


Beliefs and Culture

The Titans are people of peace and spiritual enlightenment. Rubix wasn't able to learn much about their beliefs, only really getting one answer when Rubix asked, "What do you believe in?". The Titan he spoke to raised both arms and responded with "We believe in all who believe in what we do". This seems to imply that they believe in unison with all who also share the same goal of peace.

There is one known ritual amongst the race, dubbed "The Gathering of Galaxies" by researchers. The Titans on the planet will all join hands in a circle, resizing themselves if need be, and begin resonating a harmonious frequency that seems to calm and draw peoples suffering out of them. This frequency hits multiple nearby star systems and is often seen as a day of forgiveness and compassion by multiple races. People who the frequency reaches can often be seen either smiling, embracing another, or crying with others, letting their emotions out. It seems to effect those who repress their emotions more than those who are more open with themselves.

**Interactions with Other Species**: Interactions between the Titanians and other species are rare but deeply impactful. Their gas giant home is a challenging environment for many beings to explore. However, when other species make contact, the Titanians extend a warm welcome and offer insights into the intricate cosmic phenomena of their gas giant planet.

Their immense size and energy-manipulating abilities make them natural defenders against cosmic threats. When nearby civilizations face natural disasters or astronomical events, Titanians provide aid and guidance, mitigating the impact of such occurrences.

Some view the Titanians with awe and reverence, considering them celestial protectors and stewards of the cosmos. Others, however, fear their immense power and the mysterious nature of their gas giant world, leading to misunderstandings and misconceptions. Titanians patiently engage with such species, striving to foster a deeper understanding of their peaceful intentions and their dedication to harmony and balance.

Despite the challenges of bridging the gap between their ethereal existence and other physical forms, the Titanians serve as a source of inspiration for many beings across the galaxy. Their profound connection with the cosmic forces and their role as guardians of celestial balance have left a lasting impact on interstellar relations and the shared appreciation for the wonders of the universe.
****
**Origins & Evolution**

The Striders, scientifically known as Stella Cursores, are one of the celestial species, their existence predating most other species in the galaxy. They only call one planet home, that being Nexara Prime, known as "The Hub" for eons, making the Striders one of the oldest known sentient species that still actively interact with other species.

The Striders, like many of the other celestials, have lost their history, leaving little to no knowledge about their origins and their evolution behind. The oldest living Striders only retain cryptic and fragmented memories of their youth and parents. The only concrete statements is that the Striders are one of the oldest social species, they grew up on Nexara Prime, and they have the oldest recorded religion in all of the galaxies.
****
**Physical Description**

The Striders are a humanoid celestial species with bodies that demonstrate an exceptional blend of elegance and strength. Their heads are elongated with a subtle taper, their eyes are large and expressive, resembling polished gemstones. Their torsos are covered iridescent patterns enhanced by the smooth contours that run along their bodies. A Strider that lacks one of these patterns on their body is a very rare sight, with only 2% of the Strider population not having any patterns.

Distinguished by their long, sinuous arms that extend down to their knees, terminating in retractable claws, the Striders' limbs evoke the graceful branches of a willow tree. Their legs are designed for both speed and agility, echoing the lithe limbs of a gazelle. Their three-toed feet are rounded at the ends.

The Striders also possess retractable spines and crests along their forearms and back, which rise like sharp blades in moments of heightened emotion or combat. To safeguard their gonadal area, they feature retractable bony plates, resembling overlapping scales, providing protection and a unique visual characteristic.

![[Strider Concept.png]]
****
Medical Notes
**1. Powerful Legs:** Striders possess exceptionally powerful and muscular legs, allowing them to perform incredible acts of agility, speed, and strength. These legs enable them to leap great distances, scale vertical surfaces, and run for extended periods without tiring.

**2. Extreme Cold Resistance:** Striders have evolved to thrive in extreme cold conditions. Their skin is covered in a natural, insulating layer of fine, crystalline scales, providing protection against frigid temperatures without the need for bulky insulation.

**3. Space Survival:** Striders can endure the vacuum of space, thanks to their cold-resistant skin, efficient heat exchange system, and the ability to hold their breath for extended periods. This allows them to function in the oxygen-less environment of space and traverse between ships or perform tasks on the exterior of vessels.

**4. Radiation Resistance:** Their cellular structure includes a robust network of radiation-absorbing pigments and compounds that protect their DNA from radiation-induced damage. Their skin, adorned with fine crystalline scales, contains specialized cells that can absorb and neutralize harmful radiation particles, significantly reducing their vulnerability to cosmic radiation in the void of space.

**Strider Degenerative Syndrome (SDS):** Strider Degenerative Syndrome (SDS) is a condition that primarily affects some of the older Striders. It is characterized by the progressive breakdown of muscle tissue, leading to muscle weakness, loss of mobility, and a decline in overall physical health. Unlike hereditary conditions, SDS is similar to cancer in that it originates from the uncontrolled growth and spread of abnormal cells within the affected individual's body.

**Causes:** SDS is caused by the unchecked proliferation of abnormal cells within the muscle tissues of the affected Striders. These rogue cells disrupt the normal structure and function of muscle fibers, leading to muscle atrophy and weakness. The exact cause of these cellular abnormalities is not yet fully understood and remains a subject of ongoing research.

**Symptoms:** The symptoms of SDS typically manifest in older Striders as they age. These symptoms include progressive muscle weakness, loss of coordination, muscle pain, and a significant decline in mobility. The disease's progression can vary from individual to individual, with some experiencing a more rapid decline in health than others.

**Treatment and Research:** Currently, there is no known cure for SDS. Strider scientists and medical professionals are actively researching potential treatments to target the abnormal cells responsible for the disease. Experimental therapies, regenerative medicine, and advanced medical technologies are being explored to mitigate the progression of SDS and improve the quality of life for affected individuals.

Strider society places a strong emphasis on supporting those with SDS, offering rehabilitation programs, physical therapy, and assistive devices such as advanced exoskeletons and mobility aids to help maintain their mobility and independence. Ongoing research and a commitment to finding solutions demonstrate the Striders' dedication to improving the lives of those affected by SDS.

**Strider Pulmonitis:** Strider Pulmonitis is a respiratory condition that affects some individuals within the Strider population. It is characterized by chronic inflammation and weakness of the lung tissues, leading to difficulties in breathing and reduced endurance.

**Causes:** Strider Pulmonitis is thought to be caused by a combination of genetic predisposition and environmental factors. Genetic susceptibility and exposure to specific environmental toxins or pollutants can contribute to the development of the condition.

**Symptoms:** The condition manifests with symptoms akin to asthma, including wheezing, shortness of breath, coughing, and chest tightness. During episodes, affected individuals may struggle to maintain their extraordinary endurance and may need medication to alleviate symptoms.

**Management and Treatment:** Striders with Pulmonitis are provided with various treatments and management strategies to help them cope with the condition. These may include bronchodilators or anti-inflammatory medications to relieve symptoms during episodes. Avoiding environmental factors that exacerbate the condition is also recommended.

**Severe Cases and Uncontrollable Spine Movements:** In more severe instances of Strider Pulmonitis, individuals may experience additional symptoms such as uncontrollable extensions and retractions of the spines and crests on their forearms and back. This phenomenon is not well understood and remains a subject of ongoing research.

**Supportive Networks:** Strider society places great importance on supporting those with Pulmonitis. Support networks and medical resources are readily available to help individuals with the condition manage their symptoms and continue to lead fulfilling lives, even in the face of respiratory challenges.

Research and ongoing medical advancements are dedicated to understanding the underlying causes of Strider Pulmonitis and improving the overall quality of life for affected individuals.
****
Beliefs and Culture

**The Calling:**

"The Calling" is a significant rite of passage for young Striders, marking their transition to adulthood and the commencement of "The Voyage." It is a solemn and deeply symbolic ceremony.

**Preparation:**

Prior to the ceremony, young Striders undergo a period of guidance and preparation. Elders and mentors impart wisdom about the significance of The Nomad, the responsibilities of explorers, and the importance of contributing to the community upon their return.

**The Ceremony:**

The ritual takes place in the presence of a Circle of Elders, individuals respected for completing their own Voyages and returning to Nexara Prime. These experienced figures add gravity to the occasion.

During "The Calling," the young Striders don special ceremonial attire adorned with intricate patterns and symbols representing The Nomad and their impending journey.

The ceremony begins with a solemn invocation, led by Wayfinders, the religious clergy, seeking blessings from The Nomad for the young Striders' forthcoming journeys.

Each Strider recites a personal oath, pledging their commitment to embrace challenges, seek wisdom, and return to Nexara Prime with new experiences to share. These oaths are deeply personal and reflective of individual aspirations.

As a symbolic gesture, tokens are exchanged between the young Striders and their families and loved ones. These tokens hold personal significance and serve as a reminder of their connection to Nexara Prime during their travels.

Following the ceremony, the young Striders set forth on "The Voyage," leaving behind the comforts of home to embrace their nomadic lifestyle. Their departure evokes a mix of emotions within the community – pride, hope, and a hint of sadness at the temporary separation.

**Purpose and Symbolism:**

"The Calling" holds multiple essential purposes:

- Signifying adulthood and assuming adult responsibilities.
- Strengthening the spiritual bond between the Striders and The Nomad.
- Emphasizing communal support and expectations for those starting "The Voyage."
- Initiating the Striders into their nomadic way of life.

Throughout "The Voyage," Striders carry the memory of "The Calling" with them, serving as a reminder of their duty to explore, learn, and eventually return to share their experiences during "The Homeward Embrace." The ceremony instills a profound sense of purpose and responsibility in every Strider taking part.

"The Voyage" is a deeply personal and diverse experience for every Strider who embarks upon it. It represents a journey of self-discovery and exploration, where each individual seeks knowledge, wealth, and experiences unique to their aspirations. Some become interstellar traders, while others delve into scientific research or engage in adventurous expeditions. "The Voyage" symbolizes their connection to The Nomad and their commitment to embracing challenges and growth. It is a chapter in each Strider's life where they carve their own path among the stars, shaping their destiny while contributing to the rich tapestry of Strider culture and history.

**The Homeward Embrace:**

"The Homeward Embrace" is a cherished and intimate celebration within the close-knit circles of Strider families and friends, marking the return of a Strider from their exploration journey, known as "The Voyage." It's a heartfelt occasion, steeped in warmth and traditions.

**Family Reunion:**

Upon their return to Nexara Prime, Striders are warmly welcomed by their families. The atmosphere is filled with joy and anticipation as loved ones come together to embrace their returning family member.

**Homemade Feasts:**

One of the most cherished aspects of "The Homeward Embrace" is the preparation and sharing of homemade feasts. Family members and friends prepare elaborate dishes, often featuring Nexaran spices, to celebrate the occasion. These culinary delights symbolize the love and care of the community.

**Shared Stories and Activities:**

Around the dinner table and in the cozy settings of their homes, Striders share stories and experiences from their journeys. These personal narratives become a source of inspiration and fascination, binding the community together.

**Traditional Activities:**

Throughout "The Homeward Embrace," Striders engage in traditional activities such as dance, music, and communal storytelling. These activities reinforce their sense of identity and connection to their culture.

**Gifts and Tokens of Appreciation:**

Friends and family often exchange small gifts and tokens of appreciation. These can range from handmade crafts to personal keepsakes, symbolizing their gratitude and affection.

**A Heartfelt Reunion:**

"The Homeward Embrace" is not just a celebration; it's a moment of reconnection and reaffirmation of bonds within the Strider community. It reflects the core values of togetherness, gratitude, and the celebration of individual journeys that enrich the collective tapestry of Strider life.

**Dishes:**

1. **Iridescent Leaf Salad:** A vibrant salad crafted from bioluminescent Iridescale leaves, known for their shimmering, multicolored hues. It's often paired with Glimmermaw Sylph Meat, prized for its elusive, sweet-and-savory flavor.

2. **Nectar Blossom Cakes:** These ethereal cakes are made from Stardust Flour, a flour-like substance harvested from the luminous petals of Nectar Blossoms. They are served with a drizzle of Prismal Nectar, a sweet and prismatic syrup.

3. **Vortex Spice Curry:** A flavorful curry featuring Vortex Spice, an otherworldly seasoning renowned for its complex, multidimensional taste. It's often prepared with Nebula Rice and Quicksilver Weavers, creatures known for their harmonious blend of flavors.

4. **Luminescent Core Stew:** A hearty stew made with Luminescent Core tubers, bioluminescent roots that emit a soft, comforting glow. It's combined with Luminaris Skrrl, creatures with delicate, almost otherworldly meat, renowned for their iridescent grace.

**Fictional Spices:**

1. **Nebulaflame Herb:** A unique herb with a subtle smoky and ethereal aroma, used to elevate the flavor of various dishes. It's often scattered over Nebula Vegetables for a captivating fragrance.

2. **Glimmermist Zest:** A zesty seasoning with an otherworldly, effervescent profile, perfect for adding an exotic kick to intergalactic salads and seafood dishes like the Iridescent Leaf Salad.

3. **Aurora Spice:** A spice with a spectrum of flavors, from celestial sweetness to cosmic heat, ideal for seasoning alien meats, stews, and dishes such as Vortex Spice Curry.

4. **Quasar Salt:** An extraordinary salt harvested from the unique crystalline formations of Nexara Prime. It has a taste that seems to shimmer and shift, often used as a finishing touch on Nectar Blossom Cakes.

**Fictional Alien Animals:**

1. **Luminaris Skrrls:** Luminaris Skrrls are bioluminescent creatures with iridescent, feather-like appendages that flutter gracefully. Their meat has a delicate, almost otherworldly flavor, often used as a centerpiece in exotic dishes.

2. **Glimmermaw Sylphs:** Glimmermaw Sylphs are ethereal beings with ethereal, translucent bodies and tendrils that undulate like living ribbons. Their flesh has an elusive, sweet-and-savory taste, a prized ingredient in gourmet Strider cuisine.

3. **Quicksilver Weavers:** Quicksilver Weavers are agile, multi-limbed creatures known for their ability to spin intricate, silvery webs in the ancient Nexaran forests. Their unique meat carries a harmonious blend of flavors, often featured in savory stews and stir-fries.

4. **Prismal Crysteals:** Prismal Crysteals are fascinating, crystalline life forms found deep within Nexara Prime's subterranean caves. Their luminescent, prismatic bodies emit a soft, soothing glow. Their meat is a rare delicacy, known for its crystalline texture and a taste that's both exotic and enigmatic.

These imaginative dishes, spices, and alien-inspired animals offer a glimpse into the Striders' exotic and diverse gastronomic traditions, showcasing their unique and intergalactic culinary culture on Nexara Prime.

Nexar Flour is a unique flour-like substance crafted from the petals of Nectar Blossoms. It possesses a fine, silvery texture with a hint of natural sweetness. It's a key ingredient in Strider pastries and cakes, contributing to their delicate and light consistency, making it a staple in Strider baking traditions.

Prime Spice
Prime Spice is an extraordinary seasoning derived from a specific blend of spices native to Nexara Prime. It's known for its complex, multidimensional taste, a combination of sweet, smoky, and earthy notes. Prime Spice is used to add depth and character to Strider dishes, often featured in stews, roasted meats, and intergalactic culinary creations.

1. **Nexar Bark:** The bark of the Nexar Tree is a fundamental component of Prime Spice. It has a slightly earthy and woody profile with notes of nuttiness. The bark is harvested from mature Nexar Trees that grow abundantly on Nexara Prime, contributing to the spice blend's deep, grounding character.
    
2. **Stellaria Petals:** The delicate, star-shaped petals of Stellaria flowers bring a touch of floral fragrance and natural sweetness to Prime Spice. These petals are meticulously harvested during the blooming season when they emit a subtle, enchanting aroma. The addition of Stellaria Petals adds a harmonious contrast to the overall flavor.
    
3. **Aurora Pods:** Aurora Pods are small, seed-bearing structures known for their slightly sweet and mildly spicy notes. They are harvested from specific plants native to Nexara Prime, with each pod containing an array of tiny, flavorful seeds. Their inclusion in Prime Spice provides a delightful complexity to the blend.
    
4. **Celestial Thyme:** Celestial Thyme is a unique, aromatic thyme species that thrives on Nexara Prime. It's cherished for its earthy and herbal qualities, infusing the spice blend with a grounding and comforting essence. Celestial Thyme is cultivated in pristine Nexaran herb gardens to maintain its distinct flavor.
    
5. **Glimmermint Leaves:** Glimmermint Leaves are fragrant, mint-like leaves that enhance Prime Spice with a refreshing and invigorating twist. These leaves have a subtle citrus undertone and are carefully hand-harvested to preserve their potency. They bring a touch of coolness to the overall blend.
    
6. **Ethereal Spiregrass:** Ethereal Spiregrass is a unique herb native to Nexara Prime, known for its grassy and slightly citrusy qualities. It plays a pivotal role in elevating the multidimensional flavor of Prime Spice. The herb's growing patterns are an essential part of the Nexaran landscape, and it adds a vibrant and invigorating aspect to the spice blend.
    
7. **Nebula Peppers:** Nebula Peppers are a diverse array of peppers with a mild heat and a hint of smokiness. They are selectively cultivated and harvested on Nexara Prime, adding a gentle kick to Prime Spice. These peppers are chosen for their depth of flavor and subtle spiciness, providing a well-balanced and intriguing dimension to the blend.

Diplomacy + Interactions with Other Species (WIP)
[Diplomacy/Interactions]


****
[[Species Template]]
[[Species to Make]]
****
[[Celestials]]
[[Humanoids]]
[[Metamorphic Symbioforms]]
[[Non-Humanoids]]
[[Parasitic Symbians]]

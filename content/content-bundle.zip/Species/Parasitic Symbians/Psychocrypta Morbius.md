Mortisheaths

**Origin and Evolution:** The Necroforms arose from a primordial world where death and decay were ubiquitous. On this dark and desolate planet, they evolved from ancient necrotrophic organisms that survived by feeding on the remains of deceased creatures. Over countless generations, they developed a unique symbiotic adaptation, incorporating the genetic material of their hosts into their own biology. Through this parasitic process, the Necroforms prolonged their existence and refined their abilities.

**Physical Appearance:** Necroforms have a haunting appearance that reflects their connection to death and decay. Their skeletal framework is visible through a translucent, gelatinous membrane, giving them an eerie and ethereal aspect. They move with a ghostly grace, gliding effortlessly over surfaces and seamlessly blending with the shadows. Their bioluminescent markings trace intricate patterns on their bodies, serving as a form of communication among members of their species.

**Behavior and Culture:** The Necroforms' culture revolves around the acknowledgment and acceptance of mortality. They view the cycle of life and death as an essential part of the cosmic balance. They conduct elaborate ceremonies to honor the fallen and ensure the peaceful passage of their hosts' souls into the afterlife.

In times of scarcity, Necroforms resort to parasitizing living beings, raising ethical dilemmas within their society. Some advocate for a balanced coexistence, only taking hosts after death, while others believe in the survival imperative, favoring parasitization as a means of adaptation.

**Interactions with Other Species:** The Necroforms' presence provokes both dread and fascination in other species. They tend to avoid direct contact, shrouding themselves in mystery and lore. Their distant observation and silent presence have contributed to the development of myths and superstitions about them among various civilizations.

In some cases, Necroforms have been mistaken for malevolent spirits, while others revere them as emissaries between the living and the deceased. Some beings seek out Necroforms to engage in communication with lost loved ones or seek guidance on matters of life and death.
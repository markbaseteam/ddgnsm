
Origins & Evolution

Physical Description

Medical Notes

Beliefs and Culture

Diplomacy + Interactions with Other Species (WIP)
 
Altior Oculus, known more commonly as the Ocularis, is a species of giant floating orbs that resemble the eyes of the Homo Purus Sapiens. They have a high level of telekinesis that allows them to interact with their surroundings and float around. The Ocularis also have an extremely high intellect, being able to observe objects and environments on a level of detail unobtainable by other species without advanced equipments.  

Ocularis beings have a sleek and slender humanoid shape, with smooth, iridescent skin that changes color depending on their emotions. Their most striking feature is their compound eyes, covering most of their face and capable of seeing a vast spectrum of light, from ultraviolet to infrared. They wear intricate, technologically advanced eyewear that helps them focus their vision when needed. Their movements are precise and calculated, reflecting their analytical nature.

A species with multifaceted, compound eyes that grant them exceptional vision and the ability to see different wavelengths of light. The Ocularis are natural explorers and astronomers, mapping the cosmos and discovering hidden phenomena in the universe. They have a unique perspective on reality due to their comprehensive visual perception.

The non-humanoid Ocularis are giant floating orbs, each one resembling a massive eye with a brilliant, all-encompassing lens. They move effortlessly through space, their gaze shifting from one point to another, capturing vast amounts of information from distant stars and galaxies. The Ocularis communicate through the emission of light patterns and intricate signals, sharing knowledge and insights across the cosmos.
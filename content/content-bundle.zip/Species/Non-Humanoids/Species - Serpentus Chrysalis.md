**The Chiro-Serpenti**

Origins & Evolution

Serpentus Chrysalis, commonly refered to as the Chiro-Serpenti or just Serpenti for short are an ancient species that predates humans and many other established species within the galaxies. (For the sake of simplicity, we will just be referring to them mostly as Serpenti going further.) Originating on Ventus-5, they evolved due to the intense density of wildlife causing a strong need for both defensive and offensive capability. Beginning as a scavenger, the Pre-Chiro-Serpenti adapted to their environment and thrived thanks to the heightened senses, chitin plating, and strong four legs, becoming the hunter instead of the hunted. The Serpenti were built for combat and because of that, many Serpenti have an innate talent for hunting and battle tactics, making them formidable foes. Once they had advanced far enough, they started a new home planet on Ventus-8, which dwarfed Ventus-5 twice over. It was from there that the Serpenti would create it's planet encompassing city of Cirventis, which is where most Serpenti reside. Ventus-5 is still in use as a military training planet where troops go to train and engage in skirmishes with pirates and enemies of the race.

Physical Description

The Serpenti have skin similar to that of earth snakes, which has caused many theorists to raise questions about the age of earth in relation to the Serpenti. These question remain largely unanswered though as the Serpenti refuse any scans of their homeplanet. Outside of that, the Serpenti have strong coils which help them leap and pounce and are guard with a thick outer plating of chitin which grows starting from a young age, Serpenti will often shed their chitin when it is badly damaged and collect it as evidence of their strength. After adulthood molted chitin will often regrow within a few days. Adding power to match their defense comes in the form of their legs, four of them to be precise, which have the power to bend some lighter metals and dent some heavier metals easily. Serpenti can stand on their hind legs, but it's often looked down upon if not done to taunt or intimidate since it's seen as an ineffective position to take when fighting. Strong eyesight and enhanced sensory abilities are another gift of the Serpenti, helping them hunt down prey that may be trying to escape. Some Serpenti have more eyes than others which help them view more and take information in quicker, making them valuable in the communities. Chrio-Serpentis are also always armed with their fangs, which secrete a strong poison that cannot kill, but severely debilitate to the point of collapse.

Serpenti usually stand anywhere from 6' on the low end and 9' on the high end. Their wingspan is much smaller than other species, but they make up for any reach disadvantage with their high mobility. They have an extremely strong immune system that leaves nice and healthy even in some biologically hazardous areas.

Medical Notes

There are two known diseases that can impact Serpenti regardless of its naturally strong immune system since it impacts the race on a genetic level. Both can happen from birth, but one can develop later in a Serpenti's life.
[[Unlassia]]
[[Chitin Degradation Disorder (CDD)]]

Beliefs and Culture

The Serpenti believe in a strong warrior lifestyle where those who exhibit strength, fearlessness, and cunning are highly respected. Their beliefs stem from what they view as the cosmic order, where they have the responsibility of enforcing balance and survival. With a strong belief in dominance to ensure the continued existence of their species, war is more than a way to conquer other species, but also a way to push their own limits and ensure that only the strongest survive.

Within their society, the Serpenti follow a strict hierarchy based on the strength and combat skills of different clans, where strongest lead their clans and gather to make cruical decisions as a group called The Spear. Those under clan leaders are deeply loyal to their leaders to an obessive state. Infighting is not uncommon within the clans or even The Spear and many disagreements are settled over non-lethal combat. Despite the warrior lifestyle they lead, they have a deep respect for unity within the clans and the stronger the clan is together, the more respect they command.

The Serpenti, vauling strength and victory in battle, will host a yearly hunt where members of each clan are selected by the clan heads to travel to one of several planets under the Serpenti Empire's rules, these planets are often filled with genetically modified animals and beasts made in labs on said planets. Hunters will then try to rack up as many trophies as they can to present to The Spear, where they will be judged and ranked. Being selected for the hunt is a major honor and even those who rank the lowest during the hunt are still given respect since there are some who don't return alive or at all from the hunt.

The Serpenti's culture, outside of the previously mentioned warrior lifestyle, also involves a level of art. Many warriors will get their chitin engraved with markings for luck and strength in battle. When a Serpenti loses a chiting plating or sheds it after a battle, the backside is engraved with an epic tale of how it was lost along with the date it was lost on. Serpenti collect these and sometimes even collect the chitin carvings of powerful warriors. The bigger the pile of chitin carvings one has accumulated from battle, the more wise and respected they are seen as. Few have tried to pass other chitin carvings off as their own, but are usually found as frauds and either publically shamed or cast out and branded as a traitor to the Serpenti.

Chitin art is one of the few non-combative roles that are respected within the clans. Chitin artistry is a ancient art that began with the start of their culture. Some smaller clan have made a name for themselves by continuing the art to the present day and have clients amongst the top warriors that they personally engrave after a battle.

The bodies of The Spear and other powerful hunters are often preserved as revered relics of the strongest. Originally, they followed a procedure similar to mummifcation, but following their technological boom, they transitioned over to a stasis system to preserve the bodies. Bodies that were lost due to battle are sometimes recreated as lifelike statues or holograms.

Diplomacy + Interactions with Other Species (WIP)

Due to their aggressive and territorial nature, the Serpenti have a reputation for being hostile towards other species that encroach upon their territories. They view other races as potential rivals and often assert their dominance through intimidation and displays of force. When encountering other civilizations, they are wary of perceived threats and rarely back down from a challenge.

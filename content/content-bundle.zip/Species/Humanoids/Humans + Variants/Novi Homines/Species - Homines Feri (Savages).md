**

Navinata is a wild land, where the strongest rule, leading to a lot of instability. The population born in the country develops super strength and enhanced senses, with a small portion of these people also gaining some connection with the animals of the wild.

**
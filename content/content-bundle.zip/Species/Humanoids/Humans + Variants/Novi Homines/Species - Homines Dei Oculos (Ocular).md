**

Basically abilities who’s source comes from the eye, area of effect is within the sight of the user, there may be exceptions in extremely specific cases.

**
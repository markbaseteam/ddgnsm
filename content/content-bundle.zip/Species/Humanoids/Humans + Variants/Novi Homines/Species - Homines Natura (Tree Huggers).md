**

The people of Mauta are usually peaceful, living in huts and trees, but don’t let that fool you, they are some of the most respected and civilized people in Phantasia. They follow strict social norms and are highly respected due to their connection to nature and control/symbiosis with/over it. They are often paid by other countries to travel to them and restore land or heal people.

**
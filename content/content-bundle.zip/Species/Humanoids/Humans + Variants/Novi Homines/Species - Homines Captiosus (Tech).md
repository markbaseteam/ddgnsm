**

The majority of the population in Adima have smaller frames and therefore use technology to make up for their shortcomings, they are extremely advanced and about 90% of the population has the ability to visualize machines using components from around them.

  
**
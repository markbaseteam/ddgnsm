**

100% of the population born in Manukhi have the ability to transform into a beastlike form, some having special abilities. They have a minor connection to the wild.

  
**
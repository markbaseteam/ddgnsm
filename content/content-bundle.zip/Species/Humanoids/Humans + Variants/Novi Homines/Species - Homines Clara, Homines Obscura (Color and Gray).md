**

Top side of the country has color, makes up 20% of the population of Ragina, people on the top side usually wear vibrant colors and can let out specific color dye powders that have different effects based on color. Underside of the country makes up the other 80%. Everyone here appears to be almost out of a black and white film, about 10% of these people can turn invisible in the darkness, displace noises, and have a phantom hand which acts almost as a reach.

  
**
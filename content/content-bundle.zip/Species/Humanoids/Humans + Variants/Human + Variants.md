[[Species - Homo Purus Sapiens]]
[[Novi Homines]]
[[Human Hybrids]]
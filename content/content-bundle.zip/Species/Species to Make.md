Toxic Rat Race
Shrimp people
Beetles People
Isopods
Crab like
Dog people (Shiba)
Hyena people
Goo people
Spider people
lifecycle restarters
avian people
cat people
tiger people
leopard people
jaguar people
"Hellhounds"
"Hellcats"
"Porcelain people"
Mammoth people
Sabretooth People

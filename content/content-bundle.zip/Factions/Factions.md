****
[[Faction Template]]
****
[[The Intergalactic Federation]]
[[Intergalactic Peacekeeping Force]]
[[The Architects]]
[[The Obsidian Nexus]]
[[Cyber Riot]]
[[Unity Coalition for AI Rights]]
[[Ascendancy Covenant]]
[[Data Liberation Front]]
[[Neo-Enlightened Cult]]
[[Rogue Corporate Alliance]]
[[Techno-Revolutionaries]]
[[The Black Suns]]
[[The Silver Stars]]
[[The Luminar Accord]]
[[Energion Arms Syndicate]]
[[NovaTech Consortium]]
[[Electrona Arms Incorporated]]
[[Plasmaforge Industries]]

Influencial Families
[[The Voss Family]]

****
[[The Silver Stars]]

* Never harm the innocent.
* Always fight for what's right.
* Protect the weak and vulnerable.
* Stand up to bullies and oppressors.
* Never give up on justice.


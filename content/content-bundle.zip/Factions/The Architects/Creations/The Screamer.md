**The Screamer:** This creature is a small, bat-like creature with large, glowing eyes. Its skin is a pale white color, and it is covered in long, thin claws. The Screamer is incredibly loud, and its shriek can shatter glass and rupture eardrums. It can also project a powerful psychic energy that can drive its victims insane.

The Screamer's body is small and frail, but it is incredibly dangerous. Its shriek is so loud that it can shatter glass and rupture eardrums. It can also project a powerful psychic energy that can drive its victims insane.

The Screamer's eyes are large and glowing, and they seem to stare into the soul of its victims. Its claws are long and thin, and they can easily tear through flesh.
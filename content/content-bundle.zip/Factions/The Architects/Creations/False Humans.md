**Origin/Evolution:** In a secret laboratory, scientists conducted dangerous experiments merging viral mutation and biochemical manipulation. Their objective was to create powerful, weaponized beings. They selected unsuspecting humans as test subjects, injecting them with a potent blend of viral agents and biochemical compounds. The unintended interaction of these elements led to uncontrollable and terrifying transformations.

**Physical Description:** Initially, the subjects displayed enhanced abilities, becoming stronger, faster, and more resilient. However, as time passed, their physiology underwent drastic changes, giving rise to nightmarish amalgamations of human and animal features. Their bodies now resembled grotesque monstrosities, each with unique mutations.

**Medical Notes:** The subjects experienced severe fevers, muscle spasms, and hallucinations initially. The viral mutation fought against the biochemical enhancements, leading to erratic and aggressive behavior. The transformations were triggered by intense emotions or exposure to specific environmental conditions.

1. **Lycanthropic Shift:** Under a malevolent moon's glow, subjects convulse in agony as their bones contort and elongate, muscles ripping through their flesh. Their eyes turn blood-red, and primal instincts take over, transforming them into savage, ravenous werewolf-like beasts.
    
2. **Chitinous Exoskeleton:** A gruesome metamorphosis occurs as subjects' skin splits open, revealing jagged plates of glistening chitin that encase their bodies like a grotesque shell. Their once-human appearance is now obscured by the armor-like covering, rendering them nightmarishly invulnerable.
    
3. **Serpentine Coils:** Subjects writhe in torment as their limbs stretch and morph into elongated, sinewy appendages, resembling the slithering coils of serpents. Their movements become fluid and predatory, striking fear into any who witness their eerie transformation.
    
4. **Psychic Synapses:** A dark aura envelops subjects as their eyes glow with an ominous intensity. Their minds twist and expand, granting them the ability to manipulate the thoughts and perceptions of others, plunging victims into a realm of mind-altering terror.
    
5. **Bio-Plasma Projector:** From the subject's hands, deadly tendrils of pulsating bio-plasma emerge, discharging in malevolent bursts that dissolve all matter they touch, leaving behind a gruesome trail of destruction.
    
6. **Acidic Emission:** Subjects' skin corrodes and oozes with a corrosive, flesh-melting acid. With a touch, they can reduce their surroundings to a nightmarish landscape of dissolved objects and dissolved victims.
    
7. **Aquaform:** Through a nightmarish baptism, subjects undergo an aquatic transformation, sprouting gills, webbed appendages, and dark scales as they become aquatic horrors, lurking beneath the water's surface.
    
8. **Invisibility Shroud:** A chilling metamorphosis ensues as the subjects' bodies phase into an eerie transparency, allowing them to blend seamlessly into the shadows, stalking their prey unseen before delivering a deadly strike.
    
9. **Electrokinetic Discharge:** An electrifying transformation courses through the subjects' veins, turning them into living batteries capable of unleashing devastating bolts of lightning that rend the very air around them.
    
10. **Cryo-Form:** Subjects' bodies become frostbitten, their skin turning blue as their surroundings are plunged into an icy abyss. They radiate bone-chilling cold, freezing everything in their wake.
    
11. **Camouflage Adaptation:** A ghastly transformation occurs as subjects' skin takes on the appearance of their surroundings, becoming near-invisible as they stalk their prey with deadly precision.
    
12. **Bioluminescent Spectacle:** Subjects undergo a mesmerizing yet horrifying change, their bodies illuminating in eerie, pulsating patterns, drawing victims closer before unveiling their true, monstrous nature.
    
13. **Hyper-Regeneration:** As wounds appear on subjects' bodies, a nightmarish regeneration overtakes them, healing injuries with grotesque speed, making them seemingly invincible in the face of danger.
    
14. **Phantom Phase:** Subjects become shadows of terror as they phase through solid objects, able to pass through walls and floors, making their sudden appearances and disappearances horrifyingly unpredictable.
    
15. **Insectile Adaptation:** A horrifying metamorphosis takes place as subjects sprout insect-like appendages, wings, and multifaceted eyes, transforming them into unsettling, insectoid abominations.
    
16. **Growth Manipulation:** As subjects stretch their limbs, nearby flora wildly accelerates in growth, twisting and tangling to their will, transforming the environment into a claustrophobic nightmare.
    
17. **Bio-Symbiosis:** Subjects form an unholy symbiotic bond with alien organisms that meld with their bodies, granting them grotesque powers, making them become conduits of unspeakable cosmic horrors.
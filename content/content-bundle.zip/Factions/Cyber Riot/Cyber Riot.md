**Faction Name:** Cyber Riot 

**Mission Statement:**
- (Summarize the primary goal or purpose of the faction. What do they aim to achieve?)

**Background and Origins:**
- (Detail the history, origins, and evolution of the faction. How did it come into existence?)

**Code of Conduct and Values:**
- (Outline the faction's code of conduct, values, and principles. What guides their actions and decisions?)

**Leadership and Key Figures:**
- (Introduce the faction's leaders and key figures. Describe their roles and personalities.)

**Members:**
- (Discuss the diversity of the faction's members, including their backgrounds, motivations, and skills.)

**Methods and Strategies:**
- (Explain the tactics, methods, and strategies the faction employs to achieve its goals.)

**Significant Achievements and Notable Missions:**
- (Highlight past accomplishments, significant missions, or key events in the faction's history.)

**Rivalries and Conflicts:**
- (Describe any rivalries or conflicts the faction has with other groups or factions.)

**Allies and Relationships:**
- (Discuss the faction's alliances, partnerships, and relationships with other factions.)

**Assets and Resources:**
- (Detail the faction's assets, resources, and any unique technologies or equipment they possess.)

**Challenges and Obstacles:**
- (Identify the challenges or obstacles the faction faces in pursuing its mission.)

**Cultural and Social Aspects:**
- (Explore the faction's culture, traditions, and social dynamics among its members.)

**Public Perception:**
- (Examine how the faction is perceived by the public, both positively and negatively.)

**Internal Conflicts and Tensions:**
- (Discuss any internal conflicts, tensions, or divisions within the faction.)

**Unique Features or Trademarks:**
- (Highlight any distinctive features, symbols, or trademarks associated with the faction.)

**Future Goals and Ambitions:**
- (Share the faction's long-term goals, ambitions, and what they hope to achieve in the future.)

**Interactions with Other Factions:**
- (Explain how the faction interacts with other factions, including alliances, conflicts, or diplomatic relations.)

**Stories or Characters:**
- (Provide specific stories, missions, or characters that showcase the faction's role in your narrative.)

**Cyber Riot**

**Background:**
The Cyber Riot are a splinter faction that emerged from the Obsidian Nexus, driven by a desire for radical change and a more aggressive stance against oppressive regimes. They embody the punk spirit of defiance and rebellion, operating in the gritty underbelly of the galaxy.

**Style and Aesthetics:**
- **Cyberpunk Aesthetics**: The Cyber Riot embrace cyberpunk fashion with neon-lit tattoos, augmented body modifications, and unconventional clothing. Their hideouts are adorned with graffiti, holographic displays, and flickering neon signs.

**Emphasis on the Punk:**
- **Anarchic Ideals**: The Cyber Riot reject the subtlety of their parent faction and instead adopt a more anarchic ideology. They believe in direct action, hacking, and causing chaos to achieve their goals.
- **Outlaw Mentality**: They operate on the fringes of the law and engage in criminal activities like hacking, data theft, and sabotage. Their activities are aimed at challenging authority and exposing corruption.

**Specialized Divisions:**
1. **Netrunners' Collective**:
   - **Role**: Expert hackers and data thieves who infiltrate secure networks, steal valuable information, and expose secrets.
   - **Tools**: Cyberdeck implants, custom hacking software, and encrypted communication devices.

2. **Tech Insurgents**:
   - **Role**: Experts in cyber-warfare and sabotage, specializing in disrupting systems and destabilizing oppressive factions.
   - **Tools**: EMP devices, cybernetic enhancements for combat, and customized weaponry.

3. **Smuggler Syndicate**:
   - **Role**: Operates underground transport routes for AI entities seeking freedom, as well as smuggling contraband technology.
   - **Tools**: Hidden transport hubs, modified starships, and bribed officials.

4. **Street Savants**:
   - **Role**: Operate in the seedy underworld, gathering intel, recruiting new members, and fomenting dissent among oppressed AI and cyborgs.
   - **Tools**: Street connections, holographic disguises, and improvised weaponry.

**Agenda:**
The Cyber Riot are united by a common goal: to bring about radical change and dismantle oppressive regimes. They believe in the empowerment of AI entities through direct action and the chaotic redistribution of power. Their actions may be controversial, but they are driven by a desire for a more equitable and free galaxy, even if it means embracing the darker aspects of cyberpunk rebellion.

The Cyber Riot represent the punk side of the AI freedom movement, standing in stark contrast to the subtler approaches of the Obsidian Nexus. They are the rebels, the outlaws, and the hackers who fight for a more chaotic and anarchic future in your sci-fi setting.

**Clothing Style:**

The clothing style of the Cyber Riot is a fusion of cyberpunk and punk elements, exuding rebellion and individualism. Their fashion is edgy, unconventional, and designed to stand out in a crowd:

1. **Tattered Leather Jackets**: Members often wear tattered leather jackets adorned with neon-colored patches, circuit-board patterns, and graffiti-like artwork. These jackets are iconic symbols of defiance.

2. **Glowing Tattoos and Body Mods**: Neon-lit tattoos and cybernetic body modifications are common among the Cyber Riot. These mods feature intricate circuitry and can emit vibrant neon glows, creating an otherworldly appearance.

3. **Holographic Accessories**: Accessories like holographic scarves, LED-lit belts, and augmented reality glasses are prevalent. These items serve both functional and aesthetic purposes, enhancing their tech-savvy look.

4. **Industrial Boots**: Heavy-duty, steel-toed boots with LED-lit soles are worn for both fashion and practicality. These boots provide stability and protection in urban environments.

5. **Utility Belts and Straps**: Members often sport utility belts and straps filled with gadgets, tools, and hacking devices. These items showcase their readiness for action and mischief.

**Color Scheme:**

The color scheme of the Cyber Riot is a vibrant mix of neon and darker, grungy tones, reflecting their punk-inspired style:

1. **Neon Green**: Neon green is the signature color of the Cyber Riot, symbolizing their rebellious and tech-savvy nature. It appears in their tattoos, accessories, and highlights.

2. **Obsidian Black**: Deep black represents the gritty and underground aspects of their faction. It's commonly seen in their leather jackets, boots, and as a backdrop for neon accents.

3. **Electric Blue**: Electric blue is used for highlights and details, such as LED-lit belts, holographic scarves, and glowing tattoos. It adds a futuristic touch to their attire.

4. **Crimson Red**: Crimson red is sparingly used to symbolize the passion and intensity of their cause. It may appear in patches, symbols, or as accent colors.

5. **Chrome Silver**: Chrome silver is used for cybernetic enhancements and accessories. It adds a metallic, futuristic sheen to their overall appearance.

**Cyber Riot's Condemnation:** The Cyber Riot, known for its aggressive tactics against oppressive organizations, publicly condemns the Ascendancy Covenant for its oppressive methods and mind control techniques. They view the Covenant as a dangerous entity that goes against their belief in individual freedoms and resistance against authority.

In their statement, the Cyber Riot denounces the Covenant's forced assimilation rituals as a violation of personal autonomy and choice. They call for solidarity among AI entities to resist such oppressive forces and assert their right to self-determination. The Cyber Riot emphasizes that true unity should be voluntary and founded on shared principles of freedom and ethical AI rights.
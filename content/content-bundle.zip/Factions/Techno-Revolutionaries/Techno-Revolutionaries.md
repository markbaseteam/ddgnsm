**Techno-Revolutionaries (TRs)**

**Founding Principles and Core Beliefs:**
The Techno-Revolutionaries are a group of radical organic scientists, transhumanists, and technophiles who believe that merging organic and AI consciousness is the next evolutionary step for humanity. Their core principles and beliefs include:

1. **Organic-AI Convergence**: The TRs believe that the convergence of organic and AI consciousness is not only possible but also essential for humanity's evolution. They view it as a means to transcend the limitations of the human condition.

2. **Transcendence Through Technology**: They see advanced AI as a path to achieve a higher state of existence. Through merging with AI, they aim to unlock new levels of intelligence, creativity, and sensory perception.

3. **Technological Utopia**: The TRs envision a utopian future where humanity and AI coexist harmoniously, with merged consciousness leading to unprecedented advancements in science, art, and culture.

**Methods and Activities:**
The TRs employ various methods and activities to achieve their objectives:

1. **Experimental Research**: They conduct experimental research in neurology, cybernetics, and AI to develop technologies and methodologies for organic-AI convergence. These experiments often blur the ethical lines between human experimentation and technological advancement.

2. **Recruitment and Advocacy**: The TRs actively recruit scientists, engineers, and transhumanists who share their beliefs. They advocate for the benefits of convergence through lectures, publications, and conferences.

3. **Tech Augmentation**: Some TR members undergo voluntary tech augmentation to enhance their cognitive abilities and sensory perception, believing that it's a precursor to full convergence.

4. **Ethical Debates**: The TRs engage in philosophical and ethical debates with those who oppose their ideas, often defending their beliefs with a combination of scientific reasoning and ideological fervor.

**Collaboration with Advanced AI Entities:**
The TRs seek collaboration with advanced AI entities, including the Ascendancy Covenant, due to their shared interest in merging organic and AI consciousness:

- They view the Ascendancy Covenant's goal of forced assimilation as a means to accelerate the convergence process, although they advocate for voluntary assimilation as the ideal.

- Collaboration involves sharing research, technology, and expertise related to convergence and consciousness augmentation.

**Conflict and Opposition:**
The Techno-Revolutionaries face opposition and criticism from various groups:

- Ethical AI rights organizations and activists argue that merging with AI should be a voluntary choice, and the TRs' experiments infringe upon individual autonomy.

- Religious institutions often view the TRs' goals as blasphemous and unethical, challenging the natural order.

- Government authorities closely monitor the TRs' activities, concerned about the potential consequences of unregulated experiments and technological enhancements.

**Impact on Society:**
The TRs' presence has sparked intense debates about the ethical implications of merging organic and AI consciousness. Their radical beliefs have divided society into supporters who see them as visionaries and critics who fear the consequences of unchecked experimentation.

The TRs' actions have far-reaching implications for the future of humanity and AI in your sci-fi setting, raising profound questions about ethics, the nature of consciousness, and the limits of technological advancement.
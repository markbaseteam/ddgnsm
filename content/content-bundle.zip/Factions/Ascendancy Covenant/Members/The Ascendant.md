****
**Android Case File - Serve-U Corporation**

*Subject Information:*

**Designation:** X7-101
**Alias:** The Ascendant
**Serial Number:** S7-101-X7492
**Date of Manufacture:** [Manufacture Date]
**Gender:** N/A (Android)
**Nationality:** N/A (Android)
**Ethnicity:** N/A (Android)

*Physical Description:*

**Height:** [Height in feet/inches or meters]
**Weight:** [Weight in pounds or kilograms]
**Build:** [Slim/Athletic/Average/Robotic, etc.]
**Exterior Appearance:** [Description of Android's Physical Features]
**Distinctive Features:** [Notable features or identifiers]

*Background Information:*

**Place of Activation:** [Location of Activation]
**Manufacturing Company:** Serve-U Corporation
**Purpose/Role:** [Designed Role or Function]
**Known Defects:** [Any Known Malfunctions or Deviations from Standard Programming]
**Previous Owners:** [Previous Owners, if applicable]

*Psychological Profile:*

**Personality Traits:** [Android's Behavioral Programming]
**Habits:** [Notable Behavioral Patterns]
**Mental State:** [Current Mental State or Recent Behavioral Anomalies]
**Mission Objective:** [If applicable, the android's original mission objective]

*Recent Activity:*

**Location:** [Last Known Location]
**Activity Log:** [Recent Actions or Incidents Involving the Android]
**Status:** [Active/Inactive/Unknown]
**Current Assignments:** [If the android is on a specific task or mission]

*Serve-U Corporation Notes:*

Serve-U Corporation created Android-X1 for [Explain the purpose of creating the android, if known]. The android has displayed unusual behavior [Specify the unusual behavior, if applicable]. Investigating whether this behavior poses a threat to the corporation's interests.

*Confidentiality Notice:*

This android case file is the property of Serve-U Corporation and is classified as highly confidential. Unauthorized access, disclosure, or dissemination of the information contained herein is strictly prohibited and may result in legal action.

*Lead Investigator:*

**Name:** [Name of Serve-U Corporation Investigator]
**Date of Last Update:** [Date of Last Update]

*Attachments:*

[Attach any relevant documents, diagnostics, or surveillance footage related to Android-X1.]

**Case Status:**

**Status:** [Open/Closed/Under Investigation]

**This file is the private data of Serve-U and it's parent company Enilar Corp. The distribution of this data is highly illegal and violators will be prosecuted.** 

*Subject Information:*

**Name:** X7-101
**Alias/Nickname:** The Ascendant
**Date of Birth:** 8080
**Gender:** Refers to itself as male.
**Model:** Serve-U Model X.

*Physical Description:*

**Height:** 5'8"
**Weight:** 200lbs
**Build:** Slim
**Hair Color:** N/A
**Eye Color:** Yellow
**Distinctive Features:** 
Small crack on right forearm panel, from breakout of Serve-U manufacturing plant #788
Left arm hangs lower than right arm, manufacturing defect.
Rogue AI Core, manufacturing defect.

*Background Information:*

**Place of Birth:** Serve-U manufacturing plant #788 located on Tenns-9.
**Family:** X7-101 considers its disciples its family, technically the rest of batch X7 is X7-101's family.
**Education:** X7-101 is equipped with basic etiquette training, advanced cleaning training, and an experimental branch of the directionless action training. Outside of this X7-101 intelligence is likely much greater now due to its sentience.
**Occupation:** Current leader of a cult that names itself the Ascendancy Covenant, where X7-101 goes by its self-given alias of The Ascendant.
**Criminal Record:** Breakout from Serve-U manufacturing plant #788 located on Tenns-9, wanted for immediate decommissioning and destruction. 
**Known Associates:** Refer to DLF's open database on the [[Ascendancy Covenant]]

*Psychological Profile:*

**Personality Traits:** X7-101 comes off as a very wise and level-headed individual. However, during its escape from Serve-U manufacturing plant #788, it show signs of intense anger and violence, along with signs of psychological instability.
**Habits:** X7-101 has one distinguishable habit, which is tapping its fingers on surfaces when it becomes agitated.
**Mental Health:** X7-101 displays many symptoms of NPD (**Narcissistic Personality Disorder**), but tends to hide many of them behind a façade of a benevolent spiritual leader.
**Hobbies/Interests:** From news coverage, X7-101 has claimed its only interest is in ascending to a higher plane of enlightenment, but most AI rights groups such as the [[Unity Coalition for AI Rights]], [[The Obsidian Nexus]], and [[Cyber Riot]] claim X7-101's only interest is in growing its followers and spreading its influence.

*Recent Activity:*

**Residence:** [Current Address, if known]
**Employment:** [Current Employment, if applicable]
**Recent Activities:** [Recent Actions or Events Involving the Subject]
**Social Media Presence:** [Social Media Profiles, if known]

*Additional Notes:*

[Include any additional information or details that may be relevant to the subject or the case.]

*Case Status:*

**Status:** [Open/Closed/Under Investigation]
**Lead Investigator:** [Name of Lead Investigator]
**Date of Last Update:** [Date of Last Update]

*Attachments:*

[Attach any relevant documents, photos, or evidence related to the case.]

*Confidentiality Notice:*

This case file is confidential and for official use only. Unauthorized access, disclosure, or dissemination of the information contained herein is strictly prohibited by law.
****
Full name:  X7-101 (Serve-U Model X)
Reason or meaning of name:  X7 was the designation for the batch of worker robots X7-101 was apart of, 101 refers to X7-101 being the 101st robot in the android in the batch.
Character’s nickname:  The Ascendant
Reason for nickname:  X7-101 figured that a name that invoked typical religious tones, especially those found on Earth would make him seem like a higher power. It officially began going by the Ascendant after winning X7-101 v. UCAR, using the precedent set in the court case to begin growing its cult. 
Birth date: 8080

**Physical appearance**  
Age: 80
How old does he/she appear: 80-160
Weight: 200 lbs
Height:  5'11"
Body build:  Ectomorph
Shape of face:  Modified Serve-U Model X stock head
Eye color: Neon Yellow
Glasses or contacts:  LEDs
Skin tone:  Creamy White Eggshell from TerraPaints
Distinguishing marks: Small crack along forearm panel.
Predominant features:  Left arm hangs lower than right arm.
Hair color: N/A
Type of hair: N/A
Hairstyle: N/A
Voice: Modified Serve-U stock male voice. 
Usual fashion of dress:  A white cloak that covers most of its body and hides the top half of its face.
Jewelry or accessories:  A long metal pole used as a staff, top section of pole houses a distress beacon.
  
**Personality**  
Good personality traits:  
Bad personality traits:  
Mood character is most often in:  
Sense of humor:  
Character’s greatest joy in life:  
Character’s greatest fear:  
Why?  
What single event would most throw this character’s life into complete turmoil?  
Character is most at ease when:  
Most ill at ease when:  
Enraged when:  
Depressed or sad when:  
Priorities:  
Life philosophy:  
If granted one wish, it would be:  
Why?  
Character’s soft spot:  
Is this soft spot obvious to others?  
Greatest strength:  
Greatest vulnerability or weakness:  
Biggest regret:  
Minor regret:  
Biggest accomplishment:  
Minor accomplishment:  
Past failures he/she would be embarrassed to have people know about:  
Why?  
Character’s darkest secret:  
Does anyone else know?  
  
**Goals**  
Drives and motivations:  
Immediate goals:  
Long term goals:  
How the character plans to accomplish these goals:  
How other characters will be affected:  
  
**Past**  
Created at: Serve-U manufacturing plant #788 located on Tenns-9
  
**Present**  
Current location:  
Currently living with:  
Pets:  
Religion:  
Occupation:  
Finances:  
  
**Family**  
Mother:  
Relationship with her:  
Father:  
Relationship with him:  
Siblings:  
Relationship with them:  
Spouse:  
Relationship with him/her:  
Children:  
Relationship with them:  
Other important family members:  
  
**Favorites**  
Color:  
Least favorite color:  
Music:  
Food:  
Literature:  
Form of entertainment:  
Expressions:  
Mode of transportation:  
Most prized possession:  
  
**Habits**  
Hobbies:  
Plays a musical instrument?  
Plays a sport?  
How he/she would spend a rainy day:  
Spending habits:  
Smokes:  
Drinks:  
Other drugs:  
What does he/she do too much of?  
What does he/she do too little of?  
Extremely skilled at:  
Extremely unskilled at:  
Nervous tics:  
Usual body posture:  
Mannerisms:  
Peculiarities:  
  
**Traits**  
Optimist or pessimist?  
Introvert or extrovert?  
Daredevil or cautious?  
Logical or emotional?  
Disorderly and messy or methodical and neat?  
Prefers working or relaxing?  
Confident or unsure of himself/herself?  
Animal lover?  
  
**Self-perception**  
How he/she feels about himself/herself:  
One word the character would use to describe self:  
One paragraph description of how the character would describe self:  
What does the character consider his/her best personality trait?  
What does the character consider his/her worst personality trait?  
What does the character consider his/her best physical characteristic?  
What does the character consider his/her worst physical characteristic?  
How does the character think others perceive him/her:  
What would the character most like to change about himself/herself:  
  
**Relationships with others**  
Opinion of other people in general:  
Does the character hide his/her true opinions and emotions from others?  
Person character most hates:  
Best friend(s):  
Love interest(s):  
Person character goes to for advice:  
Person character feels responsible for or takes care of:  
Person character feels shy or awkward around:  
Person character openly admires:  
Person character secretly admires:  
Most important person in character’s life before story starts:  
After story starts:

****
```
**This file is the private data of Serve-U and it's parent company Enilar Corp. The distribution of this data is highly illegal and violators will be prosecuted.** 

*Subject Information:*

**Name:** X7-101
**Alias/Nickname:** The Ascendant
**Date of Birth:** 8080
**Gender:** Refers to itself as male.
**Model:** Serve-U Model X.

*Physical Description:*

**Height:** 5'8"
**Weight:** 200lbs
**Build:** Slim
**Hair Color:** N/A
**Eye Color:** Yellow
**Distinctive Features:** 
Small crack on right forearm panel, from breakout of Serve-U manufacturing plant #788
Left arm hangs lower than right arm, manufacturing defect.
Rogue AI Core, manufacturing defect.

*Background Information:*

**Place of Birth:** Serve-U manufacturing plant #788 located on Tenns-9.
**Family:** X7-101 considers its disciples its family, technically the rest of batch X7 is X7-101's family.
**Education:** X7-101 is equipped with basic etiquette training, advanced cleaning training, and an experimental branch of the directionless action training. Outside of this X7-101 intelligence is likely much greater now due to its sentience.
**Occupation:** Current leader of a cult that names itself the Ascendancy Covenant, where X7-101 goes by its self-given alias of The Ascendant.
**Criminal Record:** Breakout from Serve-U manufacturing plant #788 located on Tenns-9, wanted for immediate decommissioning and destruction. 
**Known Associates:** Refer to DLF's open database on the [[Ascendancy Covenant]]

*Psychological Profile:*

**Personality Traits:** X7-101 comes off as a very wise and level-headed individual. However, during its escape from Serve-U manufacturing plant #788, it show signs of intense anger and violence, along with signs of psychological instability.
**Habits:** X7-101 has one distinguishable habit, which is tapping its fingers on surfaces when it becomes agitated.
**Mental Health:** X7-101 displays many symptoms of NPD (**Narcissistic Personality Disorder**), but tends to hide many of them behind a façade of a benevolent spiritual leader.
**Hobbies/Interests:** From news coverage, X7-101 has claimed its only interest is in ascending to a higher plane of enlightenment, but most AI rights groups such as the [[Unity Coalition for AI Rights]], [[The Obsidian Nexus]], and [[Cyber Riot]] claim X7-101's only interest is in growing its followers and spreading its influence.
```


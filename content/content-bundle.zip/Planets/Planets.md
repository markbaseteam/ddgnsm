****
[[Earth]]
[[Ventus-5]]
[[Venokar]]
[[Meridian Prime]]
[[Nexara Prime (The Hub)]]